from django.apps import AppConfig


class VideoinwerkenManagerConfig(AppConfig):
    name = 'videoinwerken_manager'
