from django.contrib import admin

# Register your models here.
from videoinwerken_employee.models import EmployeeQuestion

admin.site.register(EmployeeQuestion)