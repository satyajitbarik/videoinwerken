from django.apps import AppConfig


class VideoinwerkenAdminConfig(AppConfig):
    name = 'videoinwerken_admin'
