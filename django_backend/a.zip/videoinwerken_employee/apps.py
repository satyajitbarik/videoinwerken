from django.apps import AppConfig


class VideoinwerkenEmployeeConfig(AppConfig):
    name = 'videoinwerken_employee'
