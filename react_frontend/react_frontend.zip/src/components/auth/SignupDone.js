import React, { Component } from "react";

export default class SignupDone extends Component {
  render() {
    return (
      <h3 className="mx-5">Thanks for your registration, you can now login.</h3>
    );
  }
}
