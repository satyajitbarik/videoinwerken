import React from "react";

const Landing = () => (
  <center>
    <br />
    <h3>Welcome to Video Inwerken</h3>
  </center>
);

export default Landing;
