import React from "react";

export default function Success() {
  return <div>Success! youtube video uploaded</div>;
}
